
require('dotenv').config();
const express = require('express');
const line = require('@line/bot-sdk');
const axios = require('axios');

const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET
};
const USE_TAIPEI_API = (process.env.USE_TAIPEI_API === 'true'); // env: true/false

const client = new line.Client(config);
const app = express();
app.use(express.json());

// ---------- Helper: 計算距離（公尺） ----------
function getDistanceMeters(lat1, lon1, lat2, lon2) {
  const toRad = d => d * Math.PI / 180;
  const R = 6371000;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2)**2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return Math.round(R * c);
}

// ---------- 靜態 fallback 資料（測試用） ----------
function getStaticParkingList(userLat, userLng){
  // 靜態範例：10 個假停車場，座標以 userLat/lng 小偏移做示範
  const list = [];
  for(let i=1;i<=10;i++){
    const lat = Number((userLat + i*0.0006).toFixed(6));
    const lng = Number((userLng + i*0.0006).toFixed(6));
    list.push({
      id: 'static_' + i,
      name: `假停車場 ${i}`,
      address: `示範地址 ${i}`,
      lat, lng,
      available: Math.floor(Math.random()*50) // 隨機剩餘車位
    });
  }
  // 計算距離並排序
  return list.map(p => ({...p, distance: getDistanceMeters(userLat, userLng, p.lat, p.lng)}))
             .sort((a,b)=> a.distance - b.distance)
             .slice(0,10);
}

// ---------- 台北市動態 API 抓取（若要改其他縣市，改 URL 與欄位） ----------
async function fetchTaipeiParkingMerged(){
  // 官方 JSON（靜態與即時）- 若連結改版請依 data.taipei 或市府資料更新
  const INFO_URL = 'https://tcgbusfs.blob.core.windows.net/blobfs/GetParkInfo.json';
  const AVAIL_URL = 'https://tcgbusfs.blob.core.windows.net/blobfs/GetParkAvailability.json';

  const [infoRes, availRes] = await Promise.all([
    axios.get(INFO_URL).then(r => r.data).catch(()=>null),
    axios.get(AVAIL_URL).then(r => r.data).catch(()=>null)
  ]);

  const infos = (infoRes && infoRes.park) ? infoRes.park : (Array.isArray(infoRes) ? infoRes : []);
  const avails = (availRes && availRes.parks) ? availRes.parks : (Array.isArray(availRes) ? availRes : []);

  // build map by id
  const availMap = new Map();
  for(const a of avails){
    const id = a.id || a.ID || a.Id || a.ParkID;
    if(id !== undefined) availMap.set(String(id), a);
  }

  const merged = [];
  for(const s of infos){
    // 嘗試抓不同命名的欄位
    const id = s.id || s.ID || s.Id || s.ParkID || s.SeqNo;
    const name = s.name || s.Name || s.ParkName || s.PARKNAME || s.NameZh || s.Park;
    const lat = parseFloat(s.latitude || s.Lat || s.PositionLat || s.Ycord || s.Y || s.Ycod) || parseFloat(s.PositionLat || s.PositionLat);
    const lon = parseFloat(s.longitude || s.Lon || s.PositionLon || s.Xcord || s.X || s.Xcod) || parseFloat(s.PositionLon || s.PositionLon);
    const address = s.address || s.Address || s.AddressDetail || s.Addr || '';
    if(!lat || !lon) continue;
    const a = availMap.get(String(id)) || {};
    const available = a.availablecar || a.AVAILABLECAR || a.AvailableCar || a.available || a.Available || '未知';
    merged.push({
      id: String(id || name || Math.random()),
      name: String(name || '停車場'),
      address: String(address || ''),
      lat,
      lng: lon,
      available: (available === null || available === undefined) ? '未知' : available
    });
  }
  return merged;
}

// ---------- 依 user lat/lng 找最近 10 個（會用動態資料，若失敗自動 fallback） ----------
async function findNearest10(userLat, userLng){
  if(USE_TAIPEI_API){
    try{
      const merged = await fetchTaipeiParkingMerged();
      if(Array.isArray(merged) && merged.length>0){
        const list = merged.map(p=> ({...p, distance: getDistanceMeters(userLat, userLng, p.lat, p.lng)}))
                           .sort((a,b)=> a.distance - b.distance)
                           .slice(0,10);
        return list;
      }else{
        // no data -> fallback
        return getStaticParkingList(userLat, userLng);
      }
    }catch(e){
      console.error('fetchTaipeiParkingMerged error', e.message);
      return getStaticParkingList(userLat, userLng);
    }
  }else{
    // 靜態測試模式
    return getStaticParkingList(userLat, userLng);
  }
}

// ---------- 生成 Flex carousel（最多 10） ----------
function makeParkingCarousel(parkingList){
  const bubbles = parkingList.map(p => {
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}`;
    const subtitle = `${p.address || ''}\n距離：約 ${Math.round(p.distance)} m\n剩餘：${p.available}`;
    return {
      type: 'bubble',
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          { type: 'text', text: p.name || '停車場', weight: 'bold', size: 'md', wrap: true },
          { type: 'text', text: subtitle, size: 'sm', color: '#666666', wrap: true }
        ]
      },
      footer: {
        type: 'box',
        layout: 'vertical',
        contents: [
          { type: 'button', style: 'primary', action: { type: 'uri', label: '導航去這裡', uri: mapsUrl } }
        ]
      }
    };
  });
  return { type: 'flex', altText: '附近停車場', contents: { type: 'carousel', contents: bubbles } };
}

// ---------- webhook route ----------
// 注意：LINE webhook URL 要設成 https://your-app.onrender.com/webhook
app.post('/webhook', line.middleware(config), (req, res) => {
  // 立刻回 200（避免 LINE timeout），然後非同步處理事件
  res.status(200).end();

  const events = req.body.events || [];
  events.forEach(async (ev) => {
    try {
      if(ev.type === 'message' && ev.message && ev.message.type === 'location'){
        const lat = Number(ev.message.latitude);
        const lng = Number(ev.message.longitude);

        // 1) 找最近 10 個
        const list = await findNearest10(lat, lng);

        // 2) 若沒有結果，回文字
        if(!list || list.length === 0){
          await client.replyMessage(ev.replyToken, { type: 'text', text: '抱歉，找不到附近停車場資料。' });
          return;
        }

        // 3) 生成並回覆 Flex
        const flex = makeParkingCarousel(list);
        await client.replyMessage(ev.replyToken, flex);
      } else {
        // 其它訊息：提示使用者傳位置（或你也可以忽略）
        if(ev.replyToken){
          await client.replyMessage(ev.replyToken, { type: 'text', text: '請點圖文選單 → 傳送位置（LINE 內建），我會回傳你附近的停車場。' });
        }
      }
    } catch(err){
      console.error('event handler error', err);
      try{
        if(ev.replyToken) await client.replyMessage(ev.replyToken, { type: 'text', text: '系統發生錯誤，請稍後再試。' });
      }catch(e){}
    }
  });
});

// health check 或根路由（Render 打開時可檢查）
app.get('/', (req, res) => res.send('OK - LINE parking bot'));

// start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server listening on ${PORT}`));
