require('dotenv').config();
const express = require('express');
const { Client, middleware } = require('@line/bot-sdk');

const config = {
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET
};

const client = new Client(config);
const app = express();

app.post('/webhook', middleware(config), (req, res) => {
  Promise.all(req.body.events.map(handleEvent))
    .then(() => res.status(200).end())
    .catch((err) => {
      console.error(err);
      res.status(500).end();
    });
});

// 假停車格資料
const parkingLots = [
  { name: "停車場A", address: "台北市信義路1段1號", lat: 25.033, lng: 121.565 },
  { name: "停車場B", address: "台北市信義路2段2號", lat: 25.032, lng: 121.566 },
  { name: "停車場C", address: "台北市信義路3段3號", lat: 25.034, lng: 121.567 },
  { name: "停車場D", address: "台北市信義路4段4號", lat: 25.031, lng: 121.564 },
  { name: "停車場E", address: "台北市信義路5段5號", lat: 25.035, lng: 121.568 },
  { name: "停車場F", address: "台北市信義路6段6號", lat: 25.036, lng: 121.569 },
  { name: "停車場G", address: "台北市信義路7段7號", lat: 25.037, lng: 121.570 },
  { name: "停車場H", address: "台北市信義路8段8號", lat: 25.038, lng: 121.571 },
  { name: "停車場I", address: "台北市信義路9段9號", lat: 25.039, lng: 121.572 },
  { name: "停車場J", address: "台北市信義路10段10號", lat: 25.040, lng: 121.573 }
];

async function handleEvent(event) {
  // 文字觸發 Rich menu
  if (event.type === 'message' && event.message.type === 'text') {
    if (event.message.text === '#附近停車') {
      return client.replyMessage(event.replyToken, {
        type: 'text',
        text: '請分享您目前的位置',
        quickReply: {
          items: [
            {
              type: 'action',
              action: {
                type: 'location',
                label: '傳送位置'
              }
            }
          ]
        }
      });
    }
  }

  // 使用者傳送位置
  if (event.type === 'message' && event.message.type === 'location') {
    const lat = event.message.latitude;
    const lng = event.message.longitude;

    // 產生 Flex Message 小卡
    const bubbles = parkingLots.map(lot => ({
      type: "bubble",
      body: {
        type: "box",
        layout: "vertical",
        contents: [
          { type: "text", text: lot.name, weight: "bold", size: "lg" },
          { type: "text", text: lot.address, size: "sm", color: "#555555" }
        ]
      },
      footer: {
        type: "box",
        layout: "vertical",
        contents: [
          {
            type: "button",
            style: "link",
            action: {
              type: "uri",
              label: "導航",
              uri: `https://www.google.com/maps/dir/?api=1&destination=${lot.lat},${lot.lng}`
            }
          }
        ]
      }
    }));

    return client.replyMessage(event.replyToken, {
      type: "flex",
      altText: "附近停車場",
      contents: {
        type: "carousel",
        contents: bubbles
      }
    });
  }

  return Promise.resolve(null);
}

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running at ${port}`);
});
