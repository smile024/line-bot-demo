require('dotenv').config();
const express = require('express');
const line = require('@line/bot-sdk');
const haversine = require('haversine-distance');
const axios = require('axios');

const app = express();
const client = new line.Client({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
});

// 台北市停車場 API（請自行替換成官方最新 JSON API URL）
const PUBLIC_PARKING_URL = 'https://data.taipei/api/getDatasetInfo/downloadResource?id=公有停車場JSON的ID';
const PRIVATE_PARKING_URL = 'https://data.taipei/api/getDatasetInfo/downloadResource?id=私有停車場JSON的ID';
const ONSTREET_PARKING_URL = 'https://data.taipei/api/getDatasetInfo/downloadResource?id=路邊停車JSON的ID';

app.post('/webhook', line.middleware(client.config), (req, res) => {
  Promise.all(req.body.events.map(handleEvent))
    .then(result => res.json(result))
    .catch(err => {
      console.error(err);
      res.status(500).end();
    });
});

async function fetchParkingData() {
  const results = [];

  const pubRes = await axios.get(PUBLIC_PARKING_URL);
  pubRes.data.forEach(p => results.push({
    name: p.name,
    lat: parseFloat(p.latitude),
    lng: parseFloat(p.longitude),
    type: '公有',
    capacity: p.capacity || 0
  }));

  const priRes = await axios.get(PRIVATE_PARKING_URL);
  priRes.data.forEach(p => results.push({
    name: p.name,
    lat: parseFloat(p.latitude),
    lng: parseFloat(p.longitude),
    type: '私有',
    capacity: p.capacity || 0
  }));

  const onRes = await axios.get(ONSTREET_PARKING_URL);
  onRes.data.forEach(p => results.push({
    name: p.name,
    lat: parseFloat(p.latitude),
    lng: parseFloat(p.longitude),
    type: '路邊',
    capacity: p.capacity || 0
  }));

  return results;
}

async function handleEvent(event) {
  // 點擊圖文選單 / 輸入文字「附近車位」 → Quick Reply
  if (event.type === 'message' && event.message.type === 'text' && event.message.text === '附近車位') {
    const message = {
      type: 'text',
      text: '請傳送你的位置 📍',
      quickReply: {
        items: [
          {
            type: 'action',
            action: {
              type: 'location',
              label: '傳送目前位置'
            }
          }
        ]
      }
    };
    return client.replyMessage(event.replyToken, message);
  }

  // 使用者傳送位置
  if (event.type === 'message' && event.message.type === 'location') {
    const userLat = event.message.latitude;
    const userLng = event.message.longitude;

    const parkingData = await fetchParkingData();

    const nearest = parkingData
      .map(p => {
        const distance = haversine({lat: userLat, lon: userLng}, {lat: p.lat, lon: p.lng});
        return {...p, distance};
      })
      .sort((a,b) => a.distance - b.distance)
      .slice(0,10);

    const flexMessages = nearest.map(p => ({
      type: 'bubble',
      size: 'kilo',
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          { type: 'text', text: p.name, weight: 'bold', size: 'md' },
          { type: 'text', text: `${p.type} / ${p.capacity}格`, size: 'sm', color: '#999999' },
          { type: 'text', text: `距離約 ${(p.distance/1000).toFixed(2)} km`, size: 'sm', color: '#999999' },
        ]
      },
      footer: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'button',
            style: 'link',
            height: 'sm',
            action: {
              type: 'uri',
              label: '一鍵導航',
              uri: `https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lng}`
            }
          }
        ]
      }
    }));

    return client.replyMessage(event.replyToken, {
      type: 'flex',
      altText: '附近停車場',
      contents: {
        type: 'carousel',
        contents: flexMessages
      }
    });
  }

  return Promise.resolve(null);
}

app.listen(process.env.PORT, () => {
  console.log(`Bot is running on port ${process.env.PORT}`);
});
