require('dotenv').config();
const express = require('express');
const line = require('@line/bot-sdk');
const fs = require('fs');
const haversine = require('haversine-distance');

const app = express();
const client = new line.Client({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
});

// 讀取本地停車場資料
let parkingData = JSON.parse(fs.readFileSync('parking.json', 'utf8'));

// Webhook 主程式
app.post('/webhook', line.middleware(client.config), async (req, res) => {
  // 立即回 200 避免 Timeout
  res.status(200).end();

  for (const event of req.body.events) {
    handleEvent(event).catch(console.error);
  }
});

// 處理事件
async function handleEvent(event) {
  // 點擊圖文選單「附近車位」 → Quick Reply
  if (event.type === 'message' && event.message.type === 'text' && event.message.text === '附近車位') {
    const message = {
      type: 'text',
      text: '請傳送你的位置 📍',
      quickReply: {
        items: [
          {
            type: 'action',
            action: {
              type: 'location',
              label: '傳送目前位置'
            }
          }
        ]
      }
    };
    return client.replyMessage(event.replyToken, message);
  }

  // 使用者傳送位置
  if (event.type === 'message' && event.message.type === 'location') {
    const userLat = event.message.latitude;
    const userLng = event.message.longitude;

    const nearest = parkingData
      .map(p => {
        const distance = haversine({lat: userLat, lon: userLng}, {lat: p.lat, lon: p.lng});
        return {...p, distance};
      })
      .sort((a,b) => a.distance - b.distance)
      .slice(0,10);

    const flexMessages = nearest.map(p => ({
      type: 'bubble',
      size: 'kilo',
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          { type: 'text', text: p.name, weight: 'bold', size: 'md' },
          { type: 'text', text: `${p.type} / ${p.capacity}格`, size: 'sm', color: '#999999' },
          { type: 'text', text: `距離約 ${(p.distance/1000).toFixed(2)} km`, size: 'sm', color: '#999999' }
        ]
      },
      footer: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'button',
            style: 'link',
            height: 'sm',
            action: {
              type: 'uri',
              label: '一鍵導航',
              uri: `https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lng}`
            }
          }
        ]
      }
    }));

    return client.replyMessage(event.replyToken, {
      type: 'flex',
      altText: '附近停車場',
      contents: {
        type: 'carousel',
        contents: flexMessages
      }
    });
  }

  return Promise.resolve(null);
}

// 監聽 port
app.listen(process.env.PORT, () => {
  console.log(`Bot is running on port ${process.env.PORT}`);
});
