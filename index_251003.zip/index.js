const express = require("express");
const line = require("@line/bot-sdk");

const app = express();

// 用你自己的 Channel access token & secret
const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
};

const client = new line.Client(config);

// Webhook 路徑
app.post("/webhook", line.middleware(config), (req, res) => {
  Promise.all(req.body.events.map(handleEvent))
    .then((result) => res.json(result))
    .catch((err) => {
      console.error(err);
      res.status(500).end();
    });
});

function handleEvent(event) {
  if (event.type !== "message" && event.type !== "postback") {
    return Promise.resolve(null);
  }

  let message;

  // 如果使用者傳送文字「附近車位」 或 點擊圖文選單觸發同樣的文字
  if (event.type === "message" && event.message.text === "附近車位") {
    message = {
      type: "text",
      text: "請傳送你的位置 📍",
      quickReply: {
        items: [
          {
            type: "action",
            action: {
              type: "location",
              label: "傳送目前位置",
            },
          },
        ],
      },
    };
  }

  // 如果是 postback （你在 rich menu 設定 postback=parking）
  if (event.type === "postback" && event.postback.data === "parking") {
    message = {
      type: "text",
      text: "請傳送你的位置 📍",
      quickReply: {
        items: [
          {
            type: "action",
            action: {
              type: "location",
              label: "傳送目前位置",
            },
          },
        ],
      },
    };
  }

  if (message) {
    return client.replyMessage(event.replyToken, message);
  }

  return Promise.resolve(null);
}

app.listen(3000, () => {
  console.log("LINE bot is running on port 3000");
});
